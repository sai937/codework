'use strict';

function Parser(fileName) {
    try {
        if (!fileName) {
            throw 'File Name is not provided to parse.'
        } else {
            this.constructor(fileName);
            this.load();
        }
    } catch (e) {
        console.log(e);
    }
}


Parser.prototype = {
    fileName: undefined,
    // HTML id where the app is going to load tables etc.
    tableBody: undefined,
    // Entire data loaded into JS State
    data: undefined,
    // Header values are SKU numbers
    header: undefined,
    // implicitly called 
    constructor : function (fileName) {
        this.fileName = fileName;
        this.tableBody = document.getElementById('tableSKU');
    },

    // explicitly called 
    load: function() {
        // Fucntion to load data from csv 
        (function(s) {
            d3.csv(s.fileName).then(function(d) {
                s.header = d.columns;
                s.data = d;
                console.log("Loading Data complete.");
            });
        })(this);
    },
    getSKU: function(skuNumber) {
        // Fetch data for single SKU
        let fm = this.data.map( x => x[skuNumber] ) ;
        return fm;
    },
    
    getSKUs: function(sku) {
        // Fetch data for multiple SKUs given an array
        let fm = sku.map(x => this.getSKU(x));
        return fm;
    },
    verifyInput: function(skuNumbers) {
        let h = this.header;
        return skuNumbers.filter(x => h.indexOf(String(x)) > -1 );
    },

    renderTable: function(sku, given) {
        // sku = [123, 456]
        // given =[[12months],[12months]]
        let t = '' 
        var i;
        for (i=0; i<given.length ;  i++) {
            t = t +  `<tr onclick="submitGraph(`+sku[i]+`)"><th scope="row">`+sku[i]+`</th>`
            t = t + given[i].map(x => '<td>' + x + '</td>').join("") + "</tr>" ;
        }
        
        this.tableBody.innerHTML = t;
    },

    renderGraph: function(sku) {
        let data = this.data;
        var margin = {top: 20, right: 20, bottom: 30, left: 50},
            width = 960 - margin.left - margin.right,
            height = 500 - margin.top - margin.bottom;


        var svg = d3.select("#mychart")
        .append("svg")
            .attr("width", width + margin.left + margin.right)
            .attr("height", height + margin.top + margin.bottom)
        .append("g")
            .attr("transform",
                "translate(" + margin.left + "," + margin.top + ")");

        var parseTime = d3.timeParse("%Y-%m-%d");
        
        // xExtent = d3.extent(data, function(d, i) {
        //     return d.date;
        //   });
        // yExtent = d3.extent(data, function(d, i) {
        //     return d[sku];
        // });
      
        // x = d3.time.scale().domain(xExtent).range([0, width]);
        // y = d3.scale.linear().domain(yExtent).range([height, 0]);
        
        // line = d3.svg.line()
        //     .x(function(d) { return x(new Date(d.date)) })
        //     .y(function(d) { return y(d.value) });
      
        // set the ranges
        var x = d3.scaleTime().range([0, width]);
        var y = d3.scaleLinear()
                .domain([0, d3.max(data, function(d) { return +d[sku]; })])
                .range([height, 0]);

        // define the line
        var valueline = d3.line()
                .x(function(d) { return parseTime(d.date); })
                .y(function(d) { return y(d[sku]); })
                .curve(d3.curveLinear);

        x.domain(d3.extent(data, function(d) { return parseTime(d.date); }));
        y.domain([0, d3.max(data, function(d) { console.log(d[sku]);return Number(d[sku]) ;})]);
        // Add the X Axis
        svg.append("g")
            .attr("transform", "translate(0," + height + ")")
            .call(d3.axisBottom(x));
      
        // Add the Y Axis
        svg.append("g")
            .call(d3.axisLeft(y));
      
        // Add the valueline path.
        svg.append("path")
            .data(data)
            .attr("class", "line")
            .attr("d", valueline)
            .attr("stroke", "steelblue")
            .attr("stroke-width", 1.5)

        
      
    }

}