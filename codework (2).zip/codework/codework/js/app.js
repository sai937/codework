'use strict'; // so the unused variables will break the code.

// No need to change this file 
// Defining a global State to be used within application context.
let State = {}

// This init shall Load all the data 
// Promises are used for control over sync/async  execution of code. 
let init =  Promise.resolve(new Parser("../data/sku.csv"));
init.then(v =>  {
    State = v;
}).catch(e=> {
    console.log(e);
});

